package com.example.nsbmgoapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
